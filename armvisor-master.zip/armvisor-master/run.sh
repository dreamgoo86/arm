 ~/ARM/FastModelsTools_9.1/bin/model_shell -m ~/ARM/FastModelsPortfolio_9.1/examples/FVP_VE/Build_Cortex-A15x1/Linux64-Release-GCC-4.4/cadi_system_Linux64-Release-GCC-4.4.so ./kernel.elf
